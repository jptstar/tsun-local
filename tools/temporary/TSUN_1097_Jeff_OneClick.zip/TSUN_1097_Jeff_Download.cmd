@echo off
setlocal
title TSUN Local - Jeff 1097 test
set "SCRIPT=%~dp0tsun_1097_port_restart_behavior_jeff.py"
set "URL=https://raw.githubusercontent.com/jptstar/tsun-local/main/tools/temporary/tsun_1097_port_restart_behavior_jeff.py"

echo.
echo TSUN Local - Jeff GEN4/1097 test
 echo Downloading the current test script...

echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-WebRequest -UseBasicParsing '%URL%' -OutFile '%SCRIPT%' } catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 (
  echo.
  echo ERROR: Could not download the test script.
  pause
  exit /b 1
)

where py >nul 2>&1
if %errorlevel%==0 (
  py -3 "%SCRIPT%" 192.168.1.176
  goto done
)
where python >nul 2>&1
if %errorlevel%==0 (
  python "%SCRIPT%" 192.168.1.176
  goto done
)

echo.
echo ERROR: Python 3 was not found on this computer.
echo Please install Python 3, then run this file again.

:done
echo.
pause
